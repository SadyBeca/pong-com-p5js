//variáveis x,y da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 19;
let raio = diametro / 2;

//variáveis do movimento da bolinha
let velocidadexBolinha = 6;
let velocidadeyBolinha = 6;

//variáveis da Raquete1
let xRaquete1 = 5
let yRaquete1 = 150
let raqueteCompr = 10
let raqueteAlt = 90

//variáveis da Raquete2
let xRaquete2 = 585
let yRaquete2 = 150
let velocidadeyRaquete2;

//placar do jogo
let meusPontos = 0
let pontosOponente = 0

//variáveisBiblioteca
let colidiu = false;

//sons do jogo
let raquetada;
let ponto;
let trilha;

function preload(){
  trilha = loadSound("trilha.mp3");
  ponto = loadSound("ponto.mp3");
  raquetada = loadSound("raquetada.mp3");
}

function setup() {
  createCanvas(600, 400);
  trilha.loop();
}

function draw() {
  background(0);
  imagemBolinha ();
  movimentaBolinha ();
  colisaoBordaBolinha ();
  imagemraquete (xRaquete1, yRaquete1);
  movimentaRaquete1 ();
  //colisaoRaquete1Bolinha();
  verificaColisaoBolinhaRaquete(xRaquete1, yRaquete1)
  imagemraquete (xRaquete2, yRaquete2);
  //movimentaRaquete2();
  verificaColisaoBolinhaRaquete(xRaquete2, yRaquete2);
  incluiPlacar();
  marcaPonto();
  movimentaRaquete2MP();
}

function imagemBolinha () {
  circle(xBolinha, yBolinha, diametro);
  imagemraquete ();
}

function movimentaBolinha () {
  xBolinha += velocidadexBolinha;
  yBolinha += velocidadeyBolinha;
}

function colisaoBordaBolinha () {
  if (xBolinha + raio > width || xBolinha - raio < 0) {
    velocidadexBolinha *= - 1}
  if (yBolinha + raio > height || yBolinha - raio < 0) {
    velocidadeyBolinha *= - 1}
}
 
function imagemraquete (x, y){
  rect(x, y, raqueteCompr, raqueteAlt);
}

function movimentaRaquete1 () {
  if (keyIsDown(UP_ARROW)){
     yRaquete1 -= 10;
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaquete1 += 10;
  }
}

function colisaoRaquete1Bolinha() {
  if (xBolinha - raio < xRaquete1 + RaqueteCompr && yBolinha - raio < yRaquete1 + RaqueteAlt && yBolinha + raio > yRaquete1){
    velocidadexBolinha *= -1;
    raquetada.play();
  }  
}

function verificaColisaoBolinhaRaquete(x, y) {
  colidiu =   collideRectCircle(x, y, raqueteCompr, raqueteAlt, xBolinha, yBolinha, raio);
  if (colidiu){
    velocidadexBolinha *= -1
    raquetada.play();
  }                                              
}

function movimentaRaquete2(){
  velocidadeyRaquete2 = yBolinha - yRaquete2 - raqueteCompr / 2 -30;
  yRaquete2 += velocidadeyRaquete2
}

  
function incluiPlacar() {
  stroke(255);
  textAlign(CENTER);
  textSize(16);
  fill(color(255,140,0));
  rect(150, 10, 40, 20);
  fill(255);
  text(meusPontos, 170, 26);
  fill(color(255,140,0));
  rect(450, 10, 40, 20);
  fill(255);
  text(pontosOponente, 470, 26);
}

function marcaPonto(){
  if (xBolinha < 10) {
    pontosOponente += 1;
    ponto.play();
  }  
  if (xBolinha > 590) {
    meusPontos += 1;
    ponto.play();
  }
}

function movimentaRaquete2MP () {
  if (keyIsDown(87)){
     yRaquete2 -= 10;
  }
  if (keyIsDown(83)){
    yRaquete2 += 10;
  }
}